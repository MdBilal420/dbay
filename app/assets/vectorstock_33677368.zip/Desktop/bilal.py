class Node:
    
    def __init__(self,val):
        self.val = val
        self.next = None
        
        
class MyLinkedList:

    def __init__(self):
        self.head = None
        self.count = 0
        
    def get(self, index: int) -> int:
        if index >= self.count or index < 0:
            return -1
        cur = self.head
        i = 0
        #print(index,self.count)
        while index > i:
            i+=1
            cur = cur.next           
        return cur.val
        

    def addAtHead(self, val: int) -> None:
        new = Node(val)
        if not self.head:
            self.head = new
            print(new.val)
        else:
            new.next = self.head
            self.head = new
        self.count+=1
        
        

    def addAtTail(self, val: int) -> None:
        new = Node(val)
        if self.count == 0:
            self.head = new
        else:
            cur = self.head
            while cur.next is not None:
                cur = cur.next
            cur.next = new
        self.count+=1
        print(new.val)
        

    def addAtIndex(self, index: int, val: int) -> None:
        if index == 0:
            return self.addAtHead(val)
        elif index > self.count and index < 0:
            return
        else:
            cur = self.head
            new = Node(val)
            i=0
            while i < index-1:
                cur = cur.next
                i+=1
            new.next = cur.next
            cur.next = new
            self.count+=1
            print(cur.val)
        

    def deleteAtIndex(self, index: int) -> None:
        if self.count == 1 and index == 0:
            self.head = None
            self.count -=1
            return
        elif self.count == index+1:
            cur = self.head
            while cur.next.next is not None:
                cur = cur.next
            cur.next = None
            self.count-=1
        elif index+1 > self.count or index < 0:
            return 
        elif index == 0:
            self.head = self.head.next
        else:
            cur = self.head
            i=0
            while i < index-1:
                cur = cur.next
                i+=1
            cur.next = cur.next.next
            self.count-=1
                
        



obj = MyLinkedList()
param_1 = obj.get(1)
obj.addAtHead(5)
obj.addAtTail(10)
obj.addAtIndex(1,30)
obj.deleteAtIndex(1)




##class Node:
##    def __init__(self,val):
##        self.val = val
##        self.next = None
##class LinkedList:
##    def __init__(self):
##        self.head = None
##        self.count = 0
##
##    def get(self,index):
##        if index > self.count or index < 0:
##            return -1
##        cur = self.head
##        i=0
##        while(i<index):
##            i+=1
##            cur = cur.next
##        return cur.val
##    def addAtHead(self,val):
##        new = Node(val)
##        if not self.head:
##            new = self.head
##        else:
##            new.next = self.head
##            self.head = new
##        self.count+=1
##    def addAtTail(self,val):
##        new = Node(val)
##        if self.count == 0:
##            self.head = new
##        else:
##            cur = self.head
##            while(cur.next is not None):
##                cur = cur.next
##            cur.next = new
##        self.cout +=1
##    def addAtIndex(self,index,val):
##        if index == 0:
##            addAtHead(val)
##        elif index > self.count or index < 0:
##            return
##        else:
##            i = 0
##            cur = self.head
##            while(i < index-1):
##                i+=1
##                cur = cur.next
##            new = Node(val)
##            new.next = cur.next
##            cur.next = new
##        self.count+=1
##    def deleteAtIndex(self,index):
##        if index <0 or index > self.count:
##            return
##        elif index == 0 and self.count == 1:
##            self.head = None
##            self.count-=1
##            return
##        elif self.count == index+1:
##            cur = self.head
##            while(cur.next.next is not None):
##                cur = cur.next
##            cur.next = None
##            self.count-=1
##        else:
##            cur = self.head
##            i = 0
##            while i < index-1:
##                i+=1
##                cur = cur.next
##            cur.next = cur.next.next
##            self.count-=1
##            
##if __name__ == '__main__':
##    obj = LinkedList()
##    obj.addAtHead(5)
##    obj.addAtIndex(1,30)
##    param_1 = obj.get(0)
##    obj.addAtTail(10)
##    obj.addAtIndex(1,20)
##    obj.deleteAtIndex(1)
##    
